1. lambda表达式
2. Functional Interfaces
3. Optionals
4. Stream 流
5. Parallel-Streams 并行流
